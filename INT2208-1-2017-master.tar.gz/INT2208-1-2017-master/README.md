# Công nghệ Phần mềm 2017 (INT2208-1)

## Danh sách lớp/nhóm
https://docs.google.com/spreadsheets/d/1YkeJ5u6uFX2PHUednWTyKRNHO92YpzQt9L-K-xe4shg/edit?usp=sharing

## Slides SE9 Ian Sommerville
https://www.dropbox.com/sh/2gd8my4lqn0d6x8/AAC-T0tt-FkDXfh26urfTvDMa?dl=0

## Thảo luận (piazza)
https://piazza.com/class/iynx56bd2om7i5
